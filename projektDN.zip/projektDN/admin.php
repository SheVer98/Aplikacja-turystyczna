<?php
session_start();
?>

<!DOCTYPE html>
<html>

<head>

    <title>Menu admina</title>
    <link href="https://fonts.googleapis.com/css2?family=Material+Icons" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="style/admin.css">
</head>

<body>
    <header>
        <nav>
            <h1>MENU ADMINA</h1>
            <h1>Witaj, <?php echo $_SESSION['email']; ?></h1>

        </nav>
    </header>

    <div class="menu">
        <a href="lista.php">LISTA</a>
        <a href="dodaj.php">DODAJ</a>
    </div>
    <p></p>
    <a href="logout.php">Wyloguj</a>
</body>

</html>
<?php

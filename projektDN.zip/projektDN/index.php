<!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="UTF-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link href="https://fonts.googleapis.com/css2?family=Material+Icons" rel="stylesheet">
	<link rel="stylesheet" href="style/main.css">
	<link rel="preconnect" href="https://fonts.googleapis.com">
	<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
	<link href="https://fonts.googleapis.com/css2?family=Press+Start+2P&display=swap" rel="stylesheet">
	<link rel="stylesheet" href="style/style.css">
</head>

<body>

	<header>

		<nav>
			<h1>Atrakcje w Europie</h1>

			<div class="menu">
				<a href="wszystkie.php">WSZYSTKIE</a>
				<a href="kategorie.php">KATEGORIE</a>
				<a href="znajdz.php">ZNAJDZ</a>
				<a href="wyznacz.php">WYZNACZ TRASE</a>
				<a href="logowanie.php">ADMIN</a>
			</div>

			<button class="hamburger">
				<span class="material-icons">menu</span>
			</button>
		</nav>

		<div class="mobile-menu">
			<a></a>
			<a href="wszystkie.php">WSZYSTKIE</a>
			<a href="kategorie.php">KATEGORIE</a>
			<a href="znajdz.php">ZNAJDZ</a>
			<a href="wyznacz.php">WYZNACZ TRASE</a>
			<a href="logowanie.php">ADMIN</a>
		</div>
	</header>

	<script src="main.js"></script>


	<div id="map" style="width: 1550px; height: 600px;"></div>

	<script>
		function initMap() {
			const latlng = new google.maps.LatLng(52, 21);
			const myOptions = {
				zoom: 4,
				center: latlng,
			};
			map = new google.maps.Map(
				document.getElementById("map"),
				myOptions
			);

		}
	</script>
	<script type="text/javascript" src=<?php include_once 'db.php';
										echo $klucz ?>>
	</script>


</body>

</html>
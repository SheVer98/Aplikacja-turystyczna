<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <script src="https://unpkg.com/axios/dist/axios.min.js"></script>
  <link rel="stylesheet" href="style/dodaj.css">

</head>
<a href="admin.php">Cofnij</a>

<body>
  <?php
  include_once 'db.php';
  ?>



  <div class="container">
    <h1 id="text-center">Podaj adres: </h1>
    <form id="location-form">
      <input type="text" id="location-input" class="form-control form-control-lg">
      <br>
      <input type="submit" name="submit" value="Zatwierdz">
    </form>
    <div class="card-block" id="formatted-address"></div>
    <div class="card-block" id="geometry"></div>
  </div>

  <form action="insert.php" method="post">
    <h1 id="text-center">Dodaj nowy rekord: </h1>
    <?php if (isset($_GET['error'])) { ?>
      <p class="error"><?php echo $_GET['error']; ?></p>
    <?php  } ?>
    <div class="form-group">
      <label>Adres</label>
      <input type="adres" name="adres" class="form-control">
      <label>Opis</label>
      <input type="opis" name="opis" class="form-control">
    </div>
    <div class="form-group">
      <label>Nazwa</label>
      <input type="nazwa" name="nazwa" class="form-control">
    </div>
    <div class="form-group">
      <label>Szerokosc geograficzna</label>
      <input type="szerokosc" name="szerokosc" class="form-control">
    </div>
    <div class="form-group">
      <label>Dlugosc geograficzna</label>
      <input type="dlugosc" name="dlugosc" class="form-control">
    </div>
    <div class="form-group">
      <label>Link do obrazka</label>
      <input type="link1" name="link1" class="form-control">
    </div>
    <div class="form-group">
      <label>Link do informacji</label>
      <input type="link2" name="link2" class="form-control">
    </div>
    <div class="form-group">
      <label>Kategoria</label>
      <select name="kategoria">
        <option>zabytek</option>
        <option>krajobraz</option>
        <option>inne</option>
      </select>
    </div>
    <input type="submit" name="submit" value="Zatwierdz">
  </form>


  <script>
    // Pobierz formularz lokalizacji
    var locationForm = document.getElementById('location-form');

    // Oczekuj na zatwierdzenie
    locationForm.addEventListener('submit', geocode);



    function geocode(e) {
      // Zapobiegaj przesylaniu
      e.preventDefault();

      var location = document.getElementById('location-input').value;

      axios.get('https://maps.googleapis.com/maps/api/geocode/json', {
          params: {

            address: location,
            key: "<?php echo "$klucz2" ?>"
          }
        })
        .then(function(response) {
          // Log full response
          console.log(response);

          // Formatowany adres
          var formattedAddress = response.data.results[0].formatted_address;
          var formattedAddressOutput = `
          <ul class="list-group">
            <li class="list-group-item">${formattedAddress}</li>
          </ul>
        `;

          // Geometria
          var lat = response.data.results[0].geometry.location.lat;
          var lng = response.data.results[0].geometry.location.lng;
          var geometryOutput = `
          <ul class="list-group">
            <li class="list-group-item"><strong>Szerokosc geograficzna</strong>: ${lat}</li>
            <li class="list-group-item"><strong>Dlugosc geograficzna</strong>: ${lng}</li>
          </ul>
        `;

          // Wyjscie z aplikacji
          document.getElementById('formatted-address').innerHTML = formattedAddressOutput;
          document.getElementById('geometry').innerHTML = geometryOutput;
        })
        .catch(function(error) {
          console.log(error);
        });
    }
  </script>
</body>

</html>
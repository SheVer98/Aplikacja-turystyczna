<?php
include_once 'db.php';
$result = mysqli_query($conn, "SELECT * FROM maps");
?>

<!DOCTYPE html>
<html>

<head>
	<link rel="stylesheet" href="style/lista.css">
	<title>Lista atrakcji</title>
</head>

<body>

	<a href="admin.php">Cofnij</a>

	<table class="styled-table">
		<tr>
			<td>Nazwa</td>
			<td>Obraz</td>
			<td>Adres</td>
			<td>Dlugosc</td>
			<td>Szerokosc</td>
			<td>Kategoria</td>
			<td>Edytuj</td>
			<td>Usun</td>
		</tr>
		<?php
		$i = 0;
		while ($row = mysqli_fetch_array($result)) {
		?>
			<tr class="<?php if (isset($classname)) echo $classname; ?>">
				<td><?php echo $row["nazwa"]; ?></td>
				<td><img src="<?php echo $row["link1"]; ?>" alt='Obrazek' width='100' height='100'></div>
					<div style='float:right; padding: 10px;'>
				</td>
				<td><?php echo $row["adres"]; ?></td>
				<td><?php echo $row["dlugosc"]; ?></td>
				<td><?php echo $row["szerokosc"]; ?></td>
				<td><?php echo $row["kategoria"]; ?></td>
				<td><a href="edytuj.php?id=<?php echo $row["id"];  ?>">EDYTUJ</a></td>
				<td><a href="usun.php?id=<?php echo $row["id"]; ?>">USUN</a></td>


			</tr>
		<?php
			$i++;
		}
		?>
	</table>
</body>

</html>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <script src="https://unpkg.com/axios/dist/axios.min.js"></script>
    <link rel="stylesheet" href="style/dodaj.css">
</head>
<a href="admin.php">Cofnij</a>

<p></p>

<body>

    <?php include_once 'db.php';
    $result = mysqli_query($conn, "SELECT * FROM maps WHERE id ='" . $_GET["id"] . "'");
    while ($row = mysqli_fetch_array($result)) {
        $adres = $row["adres"];
        $nazwa = $row["nazwa"];
        $opis = $row["opis"];
        $szerokosc = $row["szerokosc"];
        $dlugosc = $row["dlugosc"];
        $link1 = $row["link1"];
        $link2 = $row["link2"];
        $kategoria = $row["kategoria"];
    }
    ?>
    <form name="f" action="" method="POST">
        <h1 id="text-center">Edytuj rekord: </h1>
        <?php if (isset($_GET['error'])) { ?>
            <p class="error"><?php echo $_GET['error']; ?></p>
        <?php  } ?>
        <div class="form-group">
            <label>Adres</label>
            <input type="adres" name="adres" value="<?php
                                                    echo  $adres
                                                    ?> " class="form-control">
            <label>Opis</label>
            <input type="opis" name="opis" value="<?php
                                                    echo $opis
                                                    ?>" class="form-control">
        </div>
        <div class="form-group">
            <label>Nazwa</label>
            <input type="nazwa" name="nazwa" value="<?php
                                                    echo $nazwa
                                                    ?>" class="form-control">
        </div>
        <div class="form-group">
            <label>Szerokosc geograficzna</label>
            <input type="szerokosc" name="szerokosc" value=<?php
                                                            echo $szerokosc
                                                            ?> class="form-control">
        </div>
        <div class="form-group">
            <label>Dlugosc geograficzna</label>
            <input type="dlugosc" name="dlugosc" value=<?php
                                                        echo $dlugosc
                                                        ?> class="form-control">
        </div>
        <div class="form-group">
            <label>Link do obrazka</label>
            <input type="link1" name="link1" value="<?php
                                                    echo $link1
                                                    ?>" class="form-control">
        </div>
        <div class="form-group">
            <label>Link do informacji</label>
            <input type="link2" name="link2" value="<?php
                                                    echo $link2
                                                    ?>" class="form-control">
        </div>
        <div class="form-group">
            <label>Kategoria</label>
            <select name="kategoria">
                <option><?php echo $kategoria ?></option>
                <option>zabytek</option>
                <option>krajobraz</option>
                <option>inne</option>
            </select>
        </div>
        <input type="submit" name="submit" value="Zatwierdz">
    </form>
</body>

</html>




<?php
include_once 'db.php';


if (isset($_POST['submit'])) {
    $nazwa = $_POST['nazwa'];
    $dlugosc = $_POST['dlugosc'];
    $szerokosc = $_POST['szerokosc'];
    $adres = $_POST['adres'];
    $opis = $_POST['opis'];
    $kategoria = $_POST['kategoria'];
    $link1 = $_POST['link1'];
    $link2 = $_POST['link2'];
    if (empty($nazwa) || empty($dlugosc) || empty($szerokosc) || empty($adres) || empty($kategoria) || empty($opis) || empty($link1) || empty($link2)) {

        header("Location: edytuj.php?error=Podaj wszystkie dane");

        exit();
    }
    $sql = "UPDATE maps SET nazwa =  '$nazwa', dlugosc = '$dlugosc', szerokosc =  '$szerokosc', adres= '$adres',  opis=  '$opis', kategoria = '$kategoria',  link1 = '$link1', link2 = '$link2'
   WHERE id='" . $_GET["id"] . "'";

    if (mysqli_query($conn, $sql)) {
        header("Location: lista.php");
        exit();
    } else {
        echo "Error: " . $sql . ":-" . mysqli_error($conn);
    }
    mysqli_close($conn);
}
?>



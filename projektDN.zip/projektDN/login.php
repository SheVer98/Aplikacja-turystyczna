<?php
session_start();

include "db.php";


if (isset($_POST['username']) && isset($_POST['password'])) {

    function validate($data)
    {
        $data = trim($data);

        $data = stripslashes($data);

        $data = htmlspecialchars($data);

        return $data;
    }

    $username = validate($_POST['username']);

    $pass = validate($_POST['password']);

    if (empty($username)) {

        header("Location: logowanie.php?error=Wymagana nazwa uzytkownika");

        exit();
    } else if (empty($pass)) {

        header("Location: logowanie.php?error=Wymagane haslo");

        exit();
    } else {

        $sql = "SELECT * FROM admin WHERE email='$username' AND pass='$pass'";

        $result = mysqli_query($conn, $sql);

        if (mysqli_num_rows($result) === 1) {

            $row = mysqli_fetch_assoc($result);

            if ($row['email'] === $username && $row['pass'] === $pass) {

                echo "Logged in!";

                $_SESSION['email'] = $row['email'];

                $_SESSION['name'] = $row['name'];

                $_SESSION['id'] = $row['id'];

                header("Location: admin.php");

                exit();
            } else {

                header("Location: logowanie.php?error=Nieprawidlowa nazwa uzytkownika lub haslo");

                exit();
            }
        } else {

            header("Location: logowanie.php?error=Nieprawidlowa nazwa uzytkownika lub haslo");

            exit();
        }
    }
} else {

    header("Location: logowanie.php");

    exit();
}

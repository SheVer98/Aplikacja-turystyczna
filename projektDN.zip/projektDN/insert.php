<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="style/usun.css">

</head>
<?php
include_once 'db.php';


if (isset($_POST['submit'])) {
    $nazwa = $_POST['nazwa'];
    $dlugosc = $_POST['dlugosc'];
    $szerokosc = $_POST['szerokosc'];
    $adres = $_POST['adres'];
    $opis = $_POST['opis'];
    $kategoria = $_POST['kategoria'];
    $link1 = $_POST['link1'];
    $link2 = $_POST['link2'];
    if (empty($nazwa) || empty($dlugosc) || empty($szerokosc) || empty($adres) || empty($kategoria) || empty($opis) || empty($link1) || empty($link2)) {

        header("Location: dodaj.php?error=Podaj wszystkie dane");

        exit();
    }
    $sql = "INSERT INTO maps (nazwa, dlugosc, szerokosc, adres, opis, kategoria, link1, link2)
     VALUES ('$nazwa','$dlugosc', '$szerokosc' ,'$adres','$opis', '$kategoria', '$link1', '$link2')";
    if (mysqli_query($conn, $sql)) {
        echo "Dodano nowy rekord !";
    } else {
        echo "Error: " . $sql . ":-" . mysqli_error($conn);
    }
    mysqli_close($conn);
}
?>
<p></p>

<body>
    <a href="admin.php">Cofnij</a>
</body>

</html>
<!DOCTYPE html>
<html lang="en">

<head>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Press+Start+2P&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="style/style2.css">
</head>


<body>
    <header>
        <nav>
            <a href="index.php">Menu</a>
            <h1>Atrakcje w Europie</h1>
        </nav>
    </header>

    <div id="map" style="width: 1550px; height: 600px;"></div>

    <?php

    include_once 'db.php';

    $sql = "SELECT id, nazwa, dlugosc, szerokosc, adres, opis, kategoria, link1, link2 FROM maps";
    $result = $conn->query($sql);


    if ($result->num_rows > 0) {
        // output data of each row
        $data = [];
        while ($row = $result->fetch_assoc()) {

            $object = (object) ['nazwa' => $row["nazwa"], 'dlugosc' => $row["dlugosc"], 'szerokosc' => $row["szerokosc"], 'adres' => $row["adres"], 'opis' => $row["opis"], 'kategoria' => $row["kategoria"], 'link1' => $row["link1"], 'link2' => $row["link2"]];
            array_push($data, $object);
        }
        echo '<div style= "visibility:hidden" id="myPhpValue">' . json_encode($data) . '</div>';
    } else {
        echo "0 results";
    }
    $conn->close();
    ?>


    <script>
        let map;

        function initMap() {
            const latlng = new google.maps.LatLng(52, 21);
            const myOptions = {
                zoom: 15,
                center: latlng
            };
            map = new google.maps.Map(
                document.getElementById("map"),
                myOptions
            );

            var x = document.getElementById("myPhpValue").textContent;
            x = JSON.parse(x);
            // console.log(x)
            const markers = [];
            const nazwa = []
            const coordinates = []
            const adres = []
            const opis = []
            const kategoria = []
            const link1 = []
            const link2 = []

            for (const element of x) {
                coordinates.push(new google.maps.LatLng(element.szerokosc, element.dlugosc))
                nazwa.push(element.nazwa)
                adres.push(element.adres)
                opis.push(element.opis)
                kategoria.push(element.kategoria)
                link1.push(element.link1)
                link2.push(element.link2)
            }


            const latlngbounds = new google.maps.LatLngBounds();



            for (let i = 0; i < coordinates.length; i++) {

                markers[i] = new google.maps.Marker({
                    position: coordinates[i],
                    map: map,
                    title: "Marker nr " + i
                });


                addInfo(markers[i], '<div id="content">' +
                    '<div id="siteNotice">' +
                    "</div>" +
                    '<h2 id="firstHeading" class="firstHeading">' + nazwa[i] + '</h2>' +
                    '<div id="bodyContent">' +
                    "<p><b>" + nazwa[i] + ' - ' + "</b>" + opis[i] + "</p>" +
                    '<p>Więcej informacji:  <a href=' + link2[i] + '>' + "link</a> " + "</p>" +
                    "<div style='float:left; margin-top:1%;'><img src=" + link1[i] + " alt='Obrazek' width='350' height='300' ></div><div style='float:right; padding: 10px;'><b>" + kategoria[i] + "</b><br/>" + adres[i] + "<br/></div>", "</div>" +
                    "</div>")

                latlngbounds.extend(coordinates[i]);
            }

            map.fitBounds(latlngbounds);
        }

        function addInfo(marker, content) {
            const infowindow = new google.maps.InfoWindow({
                content: content
            });


            marker.addListener("click", () => {
                infowindow.open(map, marker);
            });
        }
    </script>
    <script type="text/javascript" src=<?php include_once 'db.php';
                                        echo $klucz; ?>>
    </script>
</body>

</html>
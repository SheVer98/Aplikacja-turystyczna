<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "maps";


//  Tu nalezy podac klucze do api
$klucz ="https://maps.googleapis.com/maps/api/js?key=AIzaSyDMHzYBB_jUxRJIYu_5BwMw48iOL7PRPhE&map_ids=b467c87907ad7711&callback=initMap";
$klucz2 ='AIzaSyDMHzYBB_jUxRJIYu_5BwMw48iOL7PRPhE';     //  wykorzystywany w pliku dodaj.php

// Laczenie z baza danych
$conn = new mysqli($servername, $username, $password, $dbname);
// Sprawdzenie polaczenia
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

<!DOCTYPE html>
<html lang="en">

<head>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Press+Start+2P&display=swap" rel="stylesheet">
  <script type="module" src="wyznacz.js"></script>
  <link rel="stylesheet" type="text/css" href="style/wyznacz.css">

</head>

<body>

  <header>
    <nav>
      <a href="index.php">Menu</a>

      <h1>WYZNACZ TRASE</h1>

    </nav>
  </header>

  <div id="container">
    <div id="map" style="width: 1550px; height: 600px;"></div>
    <div id="sidebar"></div>
  </div>
  <div style="display: none">
    <div id="floating-panel">
      <strong>Start:</strong>
      <select id="start">
        <?php

        include_once 'db.php';

        $sql = "SELECT id, nazwa, dlugosc, szerokosc, adres, opis, kategoria, link1, link2 FROM maps";
        $result = $conn->query($sql);

        while ($row = $result->fetch_assoc()) {

          unset($id, $nazwa);
          $id = $row['id'];
          $nazwa = $row['nazwa'];
          $adres = $row['adres'];
          echo '<option value="' . $adres . '">' . $nazwa . '</option>';
        }

        ?>
      </select>
      <br />
      <strong>Koniec:</strong>

      <select id="end">
        <?php

        include_once 'db.php';

        $sql = "SELECT id, nazwa, dlugosc, szerokosc, adres, opis, kategoria, link1, link2 FROM maps";
        $result = $conn->query($sql);

        while ($row = $result->fetch_assoc()) {

          unset($id, $nazwa);
          $id = $row['id'];
          $nazwa = $row['nazwa'];
          $adres = $row['adres'];
          echo '<option value="' . $adres . '">' . $nazwa . '</option>';
        }
        ?>

      </select>
      <b>Sposob podrozowania: </b>
      <select id="mode">
        <option value="DRIVING">Samochodem</option>
        <option value="WALKING">Pieszo</option>
        <option value="BICYCLING">Rowerem</option>
      </select>
    </div>


  </div>
  </script>
  <script type="text/javascript" src=<?php include_once 'db.php';
                                      echo $klucz; ?> defer>
  </script>
</body>

</html>
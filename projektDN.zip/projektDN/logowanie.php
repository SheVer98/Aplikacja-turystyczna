<!DOCTYPE html>
<html>

<head>
    <link rel="stylesheet" type="text/css" href="style/log.css">


</head>
<a href="index.php">Menu</a>
<form action="login.php" method="post">
    <h1>MENU ADMINA</h1>

    <body>
        <?php if (isset($_GET['error'])) { ?>
            <p class="error"><?php echo $_GET['error']; ?></p>
        <?php  } ?>
        <p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</p>
        <label>Nazwa uzytkownika</label>
        <label><input type="text" name="username" placeholder="Nazwa uzytkownika"><br></label>
        <label>Haslo</label>
        <label><input type="password" name="password" placeholder="Haslo"><br></label>

        <label><button type="submit">Login</button></label>

</form>
</body>

</html>
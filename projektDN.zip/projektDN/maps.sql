-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Czas generowania: 23 Paź 2022, 11:54
-- Wersja serwera: 10.4.22-MariaDB
-- Wersja PHP: 8.1.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;



-- Struktura tablicy dla `admin`
--

CREATE TABLE `admin` (
  `id` int(11) NOT NULL,
  `email` varchar(30) NOT NULL,
  `pass` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Przekazanie danych do tablicy `admin`
--

INSERT INTO `admin` (`id`, `email`, `pass`) VALUES
(1, 'admin', 'admin');

-- --------------------------------------------------------





--
-- Baza danych: `maps`
--

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `maps`
--

CREATE TABLE `maps` (
  `id` int(100) NOT NULL,
  `nazwa` varchar(100) NOT NULL,
  `dlugosc` float NOT NULL,
  `szerokosc` float NOT NULL,
  `adres` varchar(100) NOT NULL,
  `opis` varchar(500) NOT NULL,
  `kategoria` varchar(100) NOT NULL,
  `link1` varchar(350) NOT NULL,
  `link2` varchar(350) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Zrzut danych tabeli `maps`
--

INSERT INTO `maps` (`id`, `nazwa`, `dlugosc`, `szerokosc`, `adres`, `opis`, `kategoria`, `link1`, `link2`) VALUES
(1, 'Stare Miasto w Warszawie', 21.0153, 52.2477, 'pl. Zamkowy 4 00-277 Warszawa ', 'dawne miasto Stara Warszawa, najstarszy ośrodek miejski Warszawy będący zwartym zespołem architektury zabytkowej, przeważnie z XVII i XVIII wieku o średniowiecznym układzie zabudowy, otoczone pierścieniem murów obronnych z XIV–XVI wieku. Współcześnie najstarsza część i obszar MSI w dzielnicy Śródmieście.', 'zabytek', 'https://upload.wikimedia.org/wikipedia/commons/6/60/Plac_Zamkowy_w_Warszawie_widziany_z_wie%C5%BCy_ko%C5%9Bcio%C5%82a_%C5%9Bw._Anny.JPG', 'https://pl.wikipedia.org/wiki/Stare_Miasto_w_Warszawie'),
(2, 'Stare Miasto w Krakowie', 19.9377, 50.0606, 'Stare Miasto, Kraków, Polska  ', 'najstarszy obszar Krakowa. Głównymi zabytkami krakowskiego Starego Miasta są znajdujące się na Rynku Głównym oraz w jego okolicy: kościół Mariacki na Placu Mariackim, Sukiennice i wieża ratuszowa, oraz pozostałości murów obronnych – Brama Floriańska i Barbakan.', 'zabytek', 'https://upload.wikimedia.org/wikipedia/commons/thumb/5/58/Rynek_Glowny_w_Krakowie.jpg/1280px-Rynek_Glowny_w_Krakowie.jpg', 'https://pl.wikipedia.org/wiki/Stare_Miasto_w_Krakowie'),
(3, 'Zamek w Malborku', 19.0279, 54.0403, 'Starościńska 1, 82-200 Malbork, Polska ', 'Jest to największy z zachowanych w Europie średniowiecznych zamków. Trzyczęściowa twierdza obronna w stylu gotyckim składa się z Zamku Niskiego, Zamku Średniego i Zamku Wysokiego. Zamek w Malborku jest najpotężniejszą twierdzą średniowiecznej Europy. Budowę zamku rozpoczęli Krzyżacy w XIII w. Przez następne stulecia, kiedy Malbork stał się stolicą zakonu krzyżackiego, twierdza znacznie się powiększyła poprzez dodanie do niej Wielkiego Refektarzu oraz Pałacu Wielkiego Mistrza.', 'zabytek', 'https://upload.wikimedia.org/wikipedia/commons/e/e6/Zesp%C3%B3%C5%82_Zamku_Krzy%C5%BCackiego_MALBORK_01.jpg', 'https://pl.wikipedia.org/wiki/Zamek_w_Malborku'),
(4, 'Kraina Wielkich Jezior Mazurskich', 21.7301, 53.7567, 'Śniardwy, Polska', 'mezoregion, położony w północnej Polsce, obejmujący środkową część Pojezierza Mazurskiego o powierzchni 1732 km², z czego 486 km² zajmują jeziora. Jest to obszar wyjątkowy zarówno w skali całego kraju, jak i Europy – niezwykle bogaty pod względem przyrodniczym, pełen historycznych zabytków oraz uwielbiany przez miłośników sportów wodnych, wędkarstwa i letników. Wielkie Jeziora Mazurskie słyną z niezliczonych siedlisk rzadkich ptaków.', 'krajobraz', 'https://i.wpimg.pl/O/644x429/i.wp.pl/a/f/jpeg/36761/1kisajno_mazury_Mariusz_Switulski_Shutterstock.jpeg', 'https://pl.wikipedia.org/wiki/Kraina_Wielkich_Jezior_Mazurskich'),
(5, 'Energylandia', 19.4116, 49.9995, 'aleja 3 Maja 2, 32-640 Zator', ' tematyczny park rozrywki położony w Zatorze w województwie małopolskim, otwarty 14 lipca 2014 roku. Największy park rozrywki w Polsce (powierzchnia ok. 70 ha, kilkanaście kolejek górskich, w tym 2 w kategorii hyper coaster)', 'inne', 'https://lh3.googleusercontent.com/p/AF1QipMWx6Y5MdMF9nyWDV5Lf0_hb7F64L3Cbw9KelHY=s1360-w1360-h1020', 'https://pl.wikipedia.org/wiki/Energylandia'),
(6, 'Europa-Park w Rust', 7.72336, 48.2598, 'Europa-Park-Straße 2, 77977 Rust, Niemc', 'to największy park rozrywki w krajach niemieckojęzycznych i jeden z niewielu czynnych również zimą. Wewnątrz teren parku jest podzielony na europejskie strefy tematyczne, wypełnione ponad 100 atrakcjami i fantastycznymi pokazami, które przerastają najśmielsze oczekiwania. „Silver Star”, czyli zapierająca dech w piersiach, widoczna z dala i największa w Europie kolejka górska czy gigantyczna, pędząca z prędkością ponad 100 km/h kolejka drewniana „Wodan-Timburcoaster”, dzika rzeka, wodne kolejki g', 'inne', 'http://ocdn.eu/images/lech/YTg7MDA_/bbb9ce1f43c879f59b6a8a7fda519992.jpg', 'https://pl.wikipedia.org/wiki/Europa-Park'),
(7, 'Zamek Neuschwanstein', 10.7498, 47.5576, 'Neuschwansteinstraße 20, 87645 Schwangau, Niemcy', 'znany jest na całym świecie jako symbol wyidealizowanej romantycznej architektury i tragicznej historii jego właściciela. Po utracie suwerenności we własnym królestwie, Ludwig II wycofał się do własnego świata mitów, legend i baśni. Zamek Neuschwanstein, położony w Alpach w południowej części Bawarii, to jeden z najsłynniejszych i najczęściej fotografowanych zabytków w Niemczech. Odwiedza go ok. 1,5 mln turystów rocznie. Został zbudowany w 1869 r. na polecenie bawarskiego króla Ludwika II na str', 'zabytek', 'http://ocdn.eu/images/lech/MmI7MDA_/6673aec896f584052625f18f67f4e573.jpg', 'https://pl.wikipedia.org/wiki/Neuschwanstein'),
(8, 'Celle', 10.0809, 52.6264, 'Celle, Niemcy', 'to bardzo ładne miasto pomiędzy Hamburgiem a Hanowerem. Położone nad rzeką Aller słynie nie tylko z licznych zabytków, ale również z okolicznych rezerwatów przyrody, wrzosowisk i torfowisk. Wizytówką miasta jest pałac z malowniczym parkiem oraz zabudowa starego miasta – charakterystyczne kamienice szachulcowe. Warto również zobaczyć ratusz, kościół i dom Hoppener Haus wybudowany w 1532 roku. Naprzeciw Hoppener Haus zainstalowano tzw. „mówiące latarnie” – sześć latarni reprezentujących różne typy', 'zabytek', 'https://www.busemprzezswiat.pl/wp-content/uploads/2018/06/DN0B3602-1200x800.jpg', 'https://pl.wikipedia.org/wiki/Celle'),
(9, 'Wieża Eiffla', 2.29448, 48.8584, 'Champ de Mars, 5 Av. Anatole France, 75007 Paris, ', 'Najbardziej znany obiekt architektoniczny Paryża, przyciągający do siebie miliony turystów z całego świata stał się już symbolem Francji. Usytuowany na lewym brzegu Sekwany, największe wrażenie robi oglądana z ogrodów Trocadero lub z Chaps de Mars. Wieża została wybudowana na paryską Wystawę Światową w 1889 roku aby upamiętnić setną rocznicę rewolucji francuskiej. Była najwyższą konstrukcją na świecie do 1930 roku, kiedy to w Nowym Jorku wniesiono 318 - metrowy Chrysler Building.', 'zabytek', 'https://upload.wikimedia.org/wikipedia/commons/thumb/a/a8/Tour_Eiffel_Wikimedia_Commons.jpg/800px-Tour_Eiffel_Wikimedia_Commons.jpg', 'https://pl.wikipedia.org/wiki/Wie%C5%BCa_Eiffla'),
(10, 'Chamonix', 6.86943, 45.9237, 'Chamonix-Mont-Blanc, Francja', 'leży w dolinie alpejskiej, w pobliżu miejsca, gdzie stykają się ze sobą terytoria Francji, Włoch i Szwajcarii, tuż przy najwyższym szczycie Europy, Mont Blanc i to zdecydowanie przesądza o jej atrakcyjności. Chamonix jest najpopularniejszym miejscem startu wypraw na \"Białą Górę\" posiadającym bardzo dobrą bazę noclegową oraz lokalne atrakcje. To tutaj, najczęściej przyjeżdżają zorganizowane wyprawy z całego świata. Łatwiej, więc można zasięgnąć informacji o warunkach pogodowych, podzielić się doś', 'krajobraz', 'https://upload.wikimedia.org/wikipedia/commons/thumb/1/1f/Chamonix_valley_from_la_Fl%C3%A9g%C3%A8re%2C2010_07.JPG/1200px-Chamonix_valley_from_la_Fl%C3%A9g%C3%A8re%2C2010_07.JPG', 'https://pl.wikipedia.org/wiki/Chamonix-Mont-Blanc'),
(11, 'Cannes', 7.01737, 43.5528, 'Cannes, Francja', 'Dawna, mała siedziba rybacka położona w regionie Prowansji znana jest przede wszystkim z prestiżowego festiwalu filmowego, który sprawia, że Cannes rok, rocznie zmienia się w stolicę światowego kina. ', 'inne', 'https://media.zielonamapa.pl/images/europa/francja/cannes/cannes-5.jpeg', 'https://pl.wikipedia.org/wiki/Cannes'),
(12, 'Stare Miasto (Praga)', 14.4223, 50.086, '110 00 Praga-Praga 1, Czechy', 'zabytkowa dzielnica Pragi, centrum kulturalne i handlowe stolicy Czech. Do 1784 samodzielne miasto. Otacza ze wszystkich stron dawną dzielnicę żydowską - Josefov, na południe i wschód od Starego Miasta leży Nowe Miasto.', 'zabytek', 'https://upload.wikimedia.org/wikipedia/commons/4/48/Prague_from_Klementinum.jpg', 'https://pl.wikipedia.org/wiki/Stare_Miasto_(Praga)'),
(13, 'Koloseum', 12.4923, 41.89, 'Piazza del Colosseo, 1, 00184 Roma RM, Włochy', 'amfiteatr w Rzymie, wzniesiony w latach 70-72 do 80 n.e. przez Wespazjana i Tytusa – cesarzy z dynastii Flawiuszów. Odbywały się w nim m.in. walki gladiatorów, naumachie, polowania na dzikie zwierzęta (venationes). Tradycja mówi, iż w Koloseum mordowano chrześcijan, co upamiętniono krzyżem wewnątrz budowli. Od połowy XVIII wieku Koloseum jest otoczone opieką jako miejsce męczeństwa pierwszych chrześcijan, wcześniej pozyskiwano z niego bloki kamienne jako materiał budowlany. ', 'zabytek', 'https://upload.wikimedia.org/wikipedia/commons/thumb/d/de/Colosseo_2020.jpg/360px-Colosseo_2020.jpg', 'https://pl.wikipedia.org/wiki/Koloseum'),
(14, 'Wenecja', 12.3155, 45.4408, 'Wenecja, Włochy', 'miasto i gmina na północy Włoch nad Morzem Adriatyckim, stolica regionu Wenecja Euganejska. Przez ponad tysiąc lat (726–1797) miasto było stolicą niezależnej Republiki Weneckiej, która była jedną z morskich i handlowych potęg Morza Śródziemnego. Z okresu największego rozkwitu Republiki (XIII-XVI wiek) pochodzą liczne zabytki miasta, których bogactwo i forma decyduje o pierwszorzędnym znaczeniu Wenecji jako ośrodka turystyki nie tylko w skali Włoch, ale też w skali ogólnoświatowej. Zabytki te, tw', 'zabytek', 'https://ocdn.eu/pulscms-transforms/1/2e6k9kpTURBXy83ZDIyOTg4NTMwNWYxOWNkY2IzY2EzZGNkZGM4YzNiZC5qcGeWlQLNAxQAwsOVAgDNAvjCw5QGzP_M_8z_lAbM_8z_zP-UBsz_zP_M_5QGzP_M_8z_3gABoTAF', 'https://pl.wikipedia.org/wiki/Wenecja'),
(15, 'Toskania', 11.2486, 43.771, 'Toskania, Włochy', 'kraina historyczna i region administracyjny w środkowych Włoszech, położony w Apeninach Północnych (Apeniny Toskańskie) oraz nad morzami: Liguryjskim i Tyrreńskim. Od północy graniczy z Ligurią oraz Emilią-Romanią, na wschodzie z Marche i Umbrią, a na południu z Lacjum. Stolicą regionu jest Florencja. W środkowej części Toskanii znajduje się kraina historyczna, a także region winiarski o nazwie Chianti.', 'krajobraz', 'https://upload.wikimedia.org/wikipedia/commons/thumb/3/34/View_from_Villa_Vignamaggio_%285771965060%29.jpg/1280px-View_from_Villa_Vignamaggio_%285771965060%29.jpg', 'https://pl.wikipedia.org/wiki/Toskania'),
(16, 'Pałac Buckingham', -0.14189, 51.5014, 'Londyn SW1A 1AA, Wielka Brytania', 'Największy na świecie pałac królewski, który od 1837 roku pełni funkcję oficjalnej siedziby monarszej. Jedna z pereł architektury późnego baroku Pałac został zbudowany w 1703 roku jako rezydencja miejska dla księcia Buckingham, Johna Sheffielda. W roku 1761 król Wielkiej Brytanii Jerzy III wszedł w posiadanie pałacu, który został przekształcony w jego rezydencję prywatną. W ciągu kolejnych 75 lat pałac wielokrotnie rozbudowywano. W pałacu jest sześćset komnat, w tym dziewiętnaście reprezentacyjn', 'zabytek', 'https://upload.wikimedia.org/wikipedia/commons/thumb/b/b4/Buckingham_Palace%2C_London_-_April_2009.jpg/1280px-Buckingham_Palace%2C_London_-_April_2009.jpg', 'https://pl.wikipedia.org/wiki/Pa%C5%82ac_Buckingham'),
(17, 'Akropol Ateński', 23.7257, 37.9715, 'Ateny 105 58, Grecja', 'akropol w Atenach, położony na wapiennym wzgórzu o wysokości względnej 70 m (prawie 157 m n.p.m.), zamieszkany w neolicie, w okresie mykeńskim znajdował się tu pałac z megaronem, od VI w. p.n.e. miejsce kultu Ateny.', 'zabytek', 'https://upload.wikimedia.org/wikipedia/commons/thumb/c/c6/Attica_06-13_Athens_50_View_from_Philopappos_-_Acropolis_Hill.jpg/360px-Attica_06-13_Athens_50_View_from_Philopappos_-_Acropolis_Hill.jpg', 'https://pl.wikipedia.org/wiki/Akropol'),
(18, 'Alhambra', -3.58814, 37.1761, 'C. Real de la Alhambra, s/n, 18009 Granada, Hiszpa', 'warowny zespół pałacowy w Grenadzie w andaluzyjskim regionie Hiszpanii, zbudowany w latach 1232–1273 i rozbudowywany do XIV wieku. Jej rozbudowa trwała za panowania emirów z dynastii Nasrydów – Jusufa I i Muhammada V. Alhambra była twierdzą mauretańskich kalifów. W 1984 roku Twierdza Alhambra została wpisana na listę światowego dziedzictwa kultury UNESCO.', 'zabytek', 'https://fajnepodroze.pl/wp-content/webp-express/webp-images/uploads/2019/06/alhambra-768x396.jpg.webp', 'https://pl.wikipedia.org/wiki/Alhambra'),
(19, 'Sognefjorden', 6.58063, 61.1554, 'Sognefjorden, Norwegia', 'drugi pod względem długości fiord na świecie, najdłuższy w Norwegii i Europie. Znajduje się w okręgu Sogn og Fjordane. Fiord zaczyna się około 72 km na północ od Bergen i ciągnie się 203 km w głąb lądu, aż do wsi Skjolden. Szerokość fiordu waha się od 1,5 do 6 km. Najgłębszy punkt fiordu znajduje się 1308 metrów poniżej poziomu morza. Fiord posiada liczne odgałęzienia.', 'krajobraz', 'https://upload.wikimedia.org/wikipedia/commons/4/47/Sognefjord%2C_Norway.jpg', 'https://pl.wikipedia.org/wiki/Sognefjorden'),
(20, 'Lwów', 24.0297, 49.8397, 'Lwów, Obwód lwowski, Ukraina, 79000', 'Dawne polskie okno na Wschód, wielokulturowe miasto i świadek trudnej historii obu narodów, dziś otwiera swe podwoje dla turystów spragnionych kultury i dobrej zabawy. Miasto wielokrotnie oblegane przez wrogów zachwyca niezwykłą mieszanką większości stylów architektonicznych. Zwiedzanie zacząć należy od Starego Miasta, które w 1998 roku wpisane zostało na listę UNESCO.', 'zabytek', 'https://plannawypad.pl/wp-content/uploads/2021/01/lwow-miasto-z-historia-zabytkami-5ut1q6.jpg', 'https://pl.wikipedia.org/wiki/Lw%C3%B3w');

--
-- Indeksy dla zrzutów tabel
--

--
-- Indeksy dla tabeli `maps`
--
ALTER TABLE `maps`
  ADD PRIMARY KEY (`id`) USING BTREE;

--
-- AUTO_INCREMENT dla zrzuconych tabel
--

--
-- AUTO_INCREMENT dla tabeli `maps`
--
ALTER TABLE `maps`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

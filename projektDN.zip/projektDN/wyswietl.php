<?php
include_once 'db.php';

$sql = "SELECT id, nazwa, dlugosc, szerokosc, adres, opis, kategoria FROM maps";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
  // output data of each row
  while ($row = $result->fetch_assoc()) {
    echo "id: " . $row["id"] . ", nazwa: " . $row["nazwa"] . ", dlugosc: " . $row["dlugosc"] . ", szerokosc: " . $row["szerokosc"] . ", adres: " . $row["adres"] . ", opis: " . $row["opis"] . ", kategoria: " . $row["kategoria"] . "<br>";
  }
} else {
  echo "0 results";
}
$conn->close();
?>

<!DOCTYPE html>
<html>
<a href="admin.php">Cofnij</a>

</html>